"""Tests for ADP CLI."""
